package com.adobe.ats.core.models;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ResourcePath;
import org.apache.sling.models.annotations.injectorspecific.ScriptVariable;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import com.adobe.ats.core.models.Stockplex;
import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.training.core.models.StockModel;
import com.day.cq.wcm.api.designer.Style;

/**
 * This model is used to get stock data from the JCR and expose the stockplex component content via Json for a headless CMS scenerio
 *
 * When fetching the stock data, we can use a Sling model to represent the data that has been imported by the StockDataImporter class.
 * StockModel represents this data model:
 * /content/stocks
 * + ADBE [sling:OrderedFolder]
 *   + lastTrade [nt:unstructured]
 *     - companyName = <value>
 *     - sector = <value>
 *     - lastTrade = <value
 *     - ..
 */

@Model(adaptables=SlingHttpServletRequest.class,		
		adapters= {ComponentExporter.class},
        defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL,
        resourceType = {"training/components/content/stockplex"})
@Exporter(name="jackson", extensions = "json")
public class Stockplex implements ComponentExporter{
	
	@ScriptVariable
	private Resource resource;
	
    @ValueMapValue
    private String symbol;

    @ValueMapValue
    private String summary;

    @ValueMapValue
    private String showStockDetails;

    //content root of for stock data
    @ResourcePath(path = "/content/stocks")
    private Resource root;

    @ScriptVariable
    private Style currentStyle;

    //Get the stock model for the stock
    private StockModel getStock() {
    	if(root == null) return null;
    	//Check to see if the stock data was imported and exists
    	Resource stockResource = root.getChild(symbol);
    	if(stockResource == null) return null;
    	
    	return stockResource.adaptTo(StockModel.class);
    }
    
    //Getter functions
    public String getSymbol() {
        return symbol;
    }
    public String getSummary() {
        return summary;
    }
    public String getShowStockDetails() {
        return showStockDetails;
    }
    public String getCurrentPrice() {
        StockModel model = getStock();
        if(model == null) return "No Data";
    	
        return String.valueOf(model.getLastTrade());
    }

    //build a map of with the property values of the lastTrade node
    private Map<String,Object> data;
    public Map<String,Object> getData() {
        return data;
    }

    @PostConstruct
    public void constructDataMap() {
        data = new HashMap<String, Object>();
        StockModel model = getStock();
        if (symbol != null && model != null) {
                data.put("Request Date", model.getRequestDate());
                data.put("Request Time", model.getRequestTime());
                data.put("UpDown", model.getUpDown());
                data.put("Open Price", model.getOpenPrice());
                data.put("Range High", model.getRangeHigh());
                data.put("Range Low", model.getRangeLow());
                data.put("Volume",  model.getVolume());
                data.put("Company", model.getCompanyName());
                data.put("Sector", model.getSector());
                data.put("52 Week High", model.get52weekHigh());
                data.put("52 Week Low", model.get52weekLow());
                data.put("YTD % Change", model.getYtdPercentChange());   
            }
        }
    
    public String getExportedType() {
        return resource.getResourceType();
    }
    }