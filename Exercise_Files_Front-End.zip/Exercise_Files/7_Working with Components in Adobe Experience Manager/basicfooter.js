"use strict";
use(function() {
    var pages = [];
    var root = currentPage.getAbsoluteParent(2);

    //make sure that we always have a valid set of returned items
    //if navigation root is null, use the currentPage as the navigation root
    if(root == null){
    	root = currentPage;
    }
    
    log.info("################NavRoot Page: " + root.title);
    
    var it = root.listChildren(new Packages.com.day.cq.wcm.api.PageFilter());
    while (it.hasNext()) {
        var pageObject = it.next();
        pages.push(pageObject);
    }
    
	//Get the current year
	var curYear = (new Date()).getFullYear();
	
    return {
        items: pages,
        currentYear: curYear
    }	
});