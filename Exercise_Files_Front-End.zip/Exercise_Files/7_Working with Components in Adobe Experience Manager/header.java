package com.adobe.ats.core.models;

import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageFilter;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.models.annotations.*;
import org.apache.sling.models.annotations.injectorspecific.ScriptVariable;

import javax.annotation.PostConstruct;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

@Model(adaptables=SlingHttpServletRequest.class,
        resourceType = "training/components/structure/header",
        defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class Header {

    @ScriptVariable
    private Page currentPage;

    @ScriptVariable
    private SlingHttpServletRequest request;

    @PostConstruct
    private Page root() {
        if (currentPage.getAbsoluteParent(2) != null) {
            return currentPage.getAbsoluteParent(2);
        }{
            return currentPage;
        }
    }

    private List<Page> rootChildren() {
        List<Page> items = new ArrayList<Page>();
        Iterator<Page> it = root().listChildren(new PageFilter());
        while (it.hasNext()) {
            items.add(it.next());
        }
        return items;
    }

    //getters

    public String getAnonymous() {
        return (request.getRequestParameter("anonymous") != null) ?
                request.getRequestParameter("anonymous").toString() : "false";

    }

    public Page getRootPage() {
        return root();
    }

    public List<Page> getItems() {
            return rootChildren();
        }
}