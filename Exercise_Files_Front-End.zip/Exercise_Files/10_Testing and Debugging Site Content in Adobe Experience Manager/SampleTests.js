/*
 *  Copyright 2018 Adobe Systems Incorporated
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */
hobs.param("siteURL", "/content/we-train");
hobs.param("page1", "/en");
hobs.param("page2", "/en/about-us");

new hobs.TestSuite("We.Train Tests", {path:"/apps/training/tests/SampleTests.js", register: true})

    .addTestCase(new hobs.TestCase("Hero component on Home Page")
        .navigateTo("%siteURL%%page1%.html")
        .asserts.location("%siteURL%%page1%.html", true)
        .asserts.visible(".cmp-pagehero", true)
    )

    .addTestCase(new hobs.TestCase("Hero component on SubPage")
        .navigateTo("%siteURL%%page2%.html")
        .asserts.location("%siteURL%%page2%.html", true)
        .asserts.visible(".cmp-pagehero", true)
    )

    .addTestCase(new hobs.TestCase("Print Selector inserted on added")
		.navigateTo("%siteURL%%page1%.html")
		.asserts.location("%siteURL%%page1%.html", true)
		.click("a.btn-print",true)
		.asserts.isTrue(function(){ return hobs.window.location.href.indexOf("/en.print.html") > -1;})
	);